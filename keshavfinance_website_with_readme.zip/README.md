# Keshav Finance Website

This is a professional multi-page website for **Keshav Finance**, a finance business.
It includes pages for Home, About, Services, and Contact, and is styled with CSS.

## Pages
- `index.html` — Home page with hero banner
- `about.html` — About Us
- `services.html` — Services
- `contact.html` — Contact Us

## How to Use
1. Upload all files to your hosting platform (e.g., GitHub Pages or Netlify).
2. Make sure all files are in the same folder.
3. Open `index.html` in a browser to view the site.

## Contact
Email: info@keshavfinance.com  
Phone: +91 98765 43210